class Student:
    def __init__(self, name, email, city, age, contact, password):
        self.name = name
        self.email = email
        self.city = city
        self.age = age
        self.contact = contact
        self.password = password

class StudentDatabase:
    def __init__(self):
        self.students = []

    def create_student(self, name, email, city, age, contact, password):
        student = Student(name, email, city, age, contact, password)
        self.students.append(student)
        print("Student created successfully.")

    def read_student(self, email):
        for student in self.students:
            if student.email == email:
                print(f"Name: {student.name}")
                print(f"Email: {student.email}")
                print(f"City: {student.city}")
                print(f"Age: {student.age}")
                print(f"Contact: {student.contact}")
                print("Student found.")
                return
        print("Student not found.")

    def update_student(self, email, **kwargs):
        for student in self.students:
            if student.email == email:
                for key, value in kwargs.items():
                    setattr(student, key, value)
                print("Student updated successfully.")
                return
        print("Student not found.")

    def delete_student(self, email):
        for student in self.students:
            if student.email == email:
                self.students.remove(student)
                print("Student deleted successfully.")
                return
        print("Student not found.")

def main():
    database = StudentDatabase()

    while True:
        print("\n1. Create Student")
        print("2. Read Student")
        print("3. Update Student")
        print("4. Delete Student")
        print("5. Exit")
        choice = input("Enter your choice: ")

        if choice == '1':
            name = input("Enter name: ")
            email = input("Enter email: ")
            city = input("Enter city: ")
            age = int(input("Enter age: "))
            contact = input("Enter contact: ")
            password = input("Enter password: ")
            database.create_student(name, email, city, age, contact, password)

        elif choice == '2':
            email = input("Enter student email to read: ")
            database.read_student(email)

        elif choice == '3':
            email = input("Enter student email to update: ")
            field = input("Enter field to update (name/email/city/age/contact/password): ")
            value = input(f"Enter new {field}: ")
            database.update_student(email, **{field: value})

        elif choice == '4':
            email = input("Enter student email to delete: ")
            database.delete_student(email)

        elif choice == '5':
            print("Exiting program.")
            break

        else:
            print("Invalid choice. Please choose again.")

if __name__ == "__main__":
    main()
    #block willonly excute if the script is run directly not when it is imported module
